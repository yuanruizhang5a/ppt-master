(** * Bib: Bibliography *)

(* ################################################################# *)
(** * Resources cited in this volume *)

(**

[Bertot 2004] Interactive Theorem Proving and Program Development:
  Coq'Art: The Calculus of Inductive Constructions, by Yves Bertot and
  Pierre Casteran.  Springer-Verlag, 2004.
  {https://tinyurl.com/z3o7nqu}

[Chlipala 2013] Certified Programming with Dependent Types, by
  Adam Chlipala.  MIT Press.  2013.  {https://tinyurl.com/zqdnyg2}

[Lipovaca 2011] Learn You a Haskell for Great Good! A Beginner's
  Guide, by Miran Lipovaca, No Starch Press, April 2011.
  {http://learnyouahaskell.com}

[O'Sullivan 2008] Bryan O'Sullivan, John Goerzen, and Don Stewart:
  Real world Haskell - code you can believe in. O'Reilly
  2008. {http://book.realworldhaskell.org}

[Pugh 1991] Pugh, William. "The Omega test: a fast and practical
  integer programming algorithm for dependence analysis." Proceedings
  of the 1991 ACM/IEEE conference on Supercomputing. ACM, 1991.
  {https://dl.acm.org/citation.cfm?id=125848}

[Sørensen and Urzyczyn 2006] M.H. Sørensen and P. Urzyczyn. Lectures on the
  Curry-Howard Isomorphism. Studies in Logic and the Foundations of Mathematics,
  vol. 149, ed. Abramsky et al. Elsevier, 2006.

[Wadler 2015] Philip Wadler. "Propositions as types."
  Communications of the ACM 58, no. 12 (2015): 75-84.
  {https://dl.acm.org/citation.cfm?id=2699407}

*)

(* 2026-08-24 09:55 *)
